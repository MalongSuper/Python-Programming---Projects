# Email: Visualize Reset Password Email


def send_reset_email(to_email, reset_link):
    print(f"\n[FAKE EMAIL to: {to_email}]")
    print("Subject: Reset Your Password")
    print(f"Click here to reset your password: {reset_link}\n")

